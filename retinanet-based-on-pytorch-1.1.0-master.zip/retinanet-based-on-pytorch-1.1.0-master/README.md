# retinanet-based-on-pytorch-1.1.0
You can see it as an update for yhenon's retinanet
Changes I have made are:

1.realize nms in python(you don't have to do extra steps to realize nms)

2.adjust the structure of the code so you can learn any module easily

3.add lots of annotations

4.rename the variables so you can get what are they used for easier

I have not tested any big dataset for my code, because of my network speed and equipment.But based on the smal dataset I made by myself,it works.

If there is something wrong,please let me know.I am just in my second year in college and I only studied it for 4 days.So there may have some points I did not understand well.

The code only supports csv now. To run the code,just run main.py.But make sure you have put your data path into function run_the_net()

At last,thanks for reading my poor english text. And good luck!:)
